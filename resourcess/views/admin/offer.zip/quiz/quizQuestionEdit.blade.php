<input type="hidden" value="{{$quizQuestion->id}}" name="id">
<div class="col-md-12">
	<div class="form-group">
	    <label for="question_title">Question title</label>
	    <textarea placeholder="Enter Title" name="question_title" id="question_title" class="form-control" rows="1" style="resize: vertical !important"  required="">{!! $quizQuestion->question_title !!}</textarea>
	</div>
</div>

<div class="col-md-6">
    <div class="form-group">
        <label class="required" for="option1">1.Option</label>
        <input type="text" required="" value="{{$quizQuestion->option_1}}" placeholder="Enter Option" name="option1" id="option1" class="form-control ">
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label  class="required" for="option2">2.Option</label>
        <input type="text" value="{{$quizQuestion->option_2}}" required placeholder="Enter Option" name="option2" id="option2" class="form-control ">
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label  for="option3">3.Option</label>
        <input type="text" value="{{$quizQuestion->option_3}}" placeholder="Enter Option" name="option3" id="option3" class="form-control ">
    </div>
</div>
<div class="col-md-6">
    <div class="form-group">
        <label  for="option4">4.Option </label>
        <input type="text" value="{{$quizQuestion->option_4}}" placeholder="Enter Option" name="option4" id="option4" class="form-control ">
    </div>
</div>


<div class="col-md-4">
    <div class="form-group">
       <label class="required" for="answer">Answer</label>
        <input type="number" value="{{$quizQuestion->answer}}" placeholder="Enter answer number" name="answer" id="answer" required=""  class="form-control ">
       
    </div>
</div>


<div class="col-md-8">
    <div class="form-group"> 
        <label lass="required">Question type</label><br/>
        <label for="Woadi"><input type="radio" @if($quizQuestion->is_default == 1) checked @endif required id="Woadi" name="is_default" value="1">Woadi related </label> 
        <label for="National"><input @if($quizQuestion->is_default == 2) checked @endif type="radio" required name="is_default" value="2" id="National">National </label> <br/>
        <label for="International"><input @if($quizQuestion->is_default == 3) checked @endif type="radio" required name="is_default" value="3" id="International">International </label> 
        <label for="General"><input @if($quizQuestion->is_default == 4) checked @endif type="radio" required name="is_default" value="4" id="General">General knowledge</label>
    </div>
</div>